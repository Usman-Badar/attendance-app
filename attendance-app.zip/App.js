import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import * as Font from "expo-font";

import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import axios from 'axios';

import ActivityIndicator from '@ant-design/react-native/lib/activity-indicator';
import Provider from '@ant-design/react-native/lib/provider';
import Toast from '@ant-design/react-native/lib/toast';

import Auth from './screens/Auth';
import Operations from './screens/Operations';

const Stack = createNativeStackNavigator();

export default function App() {
  const server = "https://202.63.220.170:3443";
  const server_ = "https://182.180.190.108:3443";
  // const server__ = "http://192.168.100.116:8888";
  const [Url, setUrl] = useState();

  useEffect(
    () => {
      axios.create({timeout: 2000}).get(`${server}/testing`).then(() => setUrl(server)).catch(() => {
        axios.create({timeout: 2000}).get(`${server_}/testing`).then(() => setUrl(server_)).catch(err => Toast.offline(err.message));
      });
    }, []
  );

  useEffect(
    () => {
      async function loadFonts() {
        await Font.loadAsync({
          'antoutline': require('@ant-design/icons-react-native/fonts/antoutline.ttf'),
        });
        await Font.loadAsync({
          'antfill': require('@ant-design/icons-react-native/fonts/antfill.ttf'),
        });
        await Font.loadAsync({
          'cinzel': require('./assets/Cinzel-Regular.ttf'),
        });
      }
      loadFonts();
    }, []
  );

  if (!Url)
  {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#202124' }}>
        <View>
          <ActivityIndicator size={100} color="#57A2D5" />
          <Text style={{ color: '#898989', marginTop: 10, fontSize: 18, fontFamily: "antfill", letterSpacing: 2 }}>Resolving Server URL...</Text>
        </View>
        <StatusBar style="light" backgroundColor='#202124' />
      </View>
    )
  }
  return (
    <Provider>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen options={{ headerShown: false }} name="Auth" component={Auth} initialParams={{ url: Url }} />
          <Stack.Screen options={{ headerShown: false }} name="Operations" component={Operations} />
        </Stack.Navigator>
        <StatusBar style="light" backgroundColor='#202124' />
      </NavigationContainer>
    </Provider>
  );
}